var express = require('express');

var app = express();

app.use(express.static('.'));

app.listen(1111, function() {
  console.log('Server is running on port 1111');
});
