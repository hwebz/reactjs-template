var React = require('react');

module.exports = React.createClass({
  render: function() {
    return React.createElement('h1', null, 'Hello, React!');
  }
});
