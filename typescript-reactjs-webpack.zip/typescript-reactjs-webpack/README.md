# Typescript-ReactJS-Webpack
Repo for Getting Started with React, Typescript and Webpack Medium [blog post](https://medium.com/@fay_jai/getting-started-with-reactjs-typescript-and-webpack-95dcaa0ed33c#.cp7sr9ewx)

node_modules/.bin/typings install --save --ambient react
node_modules/.bin/typings install --save --ambient react-dom
